package currentless;

/**
 * Created by ashvinikumar on 18/11/16.
 */
public class CurrentLess extends Exception {
    public CurrentLess(String s)
    {
        super(s);
    }
}
