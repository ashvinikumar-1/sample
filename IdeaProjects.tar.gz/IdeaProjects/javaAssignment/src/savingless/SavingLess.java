package savingless;

/**
 * Created by ashvinikumar on 18/11/16.
 */
public class SavingLess extends Exception {
    public SavingLess(String s)
    {
        super(s);
    }
}
