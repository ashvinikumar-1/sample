package negativebal;

/**
 * Created by ashvinikumar on 18/11/16.
 */
public class NegativeBal extends Exception {
   public NegativeBal(String s)
    {
        super(s);
    }
}
