package tetinterfaces;

/**
 * Created by ashvinikumar on 23/11/16.
 */
class Employee
{
    public String firstname ;
    public String lastname ;

    Employee(String firstname , String lastname)
    {
        this.firstname = firstname;
        this.lastname = lastname;
    }
}